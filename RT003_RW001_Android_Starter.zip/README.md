# RT 003 RW 001 — Starter Project

Starter aplikasi administrasi RT berbasis React + Vite + Firebase, siap dibungkus menjadi aplikasi Android dengan Capacitor.

## Fitur awal
- Dashboard ringkasan pemasukan, pengeluaran, saldo dan grafik bulanan
- Data warga (CRUD oleh pengurus)
- Profil RT
- Pengumuman
- Role warga (read-only) dan pengurus (login)
- Sinkronisasi online melalui Firebase Firestore

## Penting
Ini adalah proyek sumber/starter, bukan APK yang sudah dikompilasi. Untuk mengaktifkan sinkronisasi online, buat project Firebase sendiri dan isi `src/firebase.js` dengan konfigurasi Firebase. Jangan masukkan data NIK asli sebelum autentikasi dan Firestore Rules diuji.

## Menjalankan di komputer
1. Install Node.js LTS.
2. Ekstrak ZIP, buka terminal di folder proyek.
3. Jalankan `npm install`
4. Salin `.env.example` menjadi `.env` dan isi variabel Firebase.
5. Jalankan `npm run dev`.

## Build Android
1. `npm run build`
2. `npx cap add android`
3. `npx cap sync android`
4. `npx cap open android`
5. Di Android Studio pilih Build > Build APK(s).

## Membuat akun pengurus
Aktifkan Email/Password di Firebase Authentication, buat akun pengurus, lalu tambahkan UID akun tersebut ke dokumen `admins/{uid}` di Firestore. Jangan pernah menjadikan seluruh pengguna sebagai admin.

## Firebase
Buat Firestore Database dan terapkan rules dari `firestore.rules`. Pastikan pengaturan security dan izin diuji sebelum dipakai warga sungguhan.
